from PIL import Image
import itertools



def loadPixels():
    img = Image.open('imgs/1.png')
    p = []
    for i in list(img.getdata()):
        p.append(i[0])
    return p

def main():

if __name__ == '__main__':
    main()
        
